# LadyDrive Android 0.3

Android application sources and optional Render backend sources.

## GitHub Actions APK build
Upload **the contents** of this folder to the root of a GitHub repository (not the ZIP itself). Open Actions -> Build LadyDrive APK -> Run workflow. After a successful build download artifact `LadyDrive-v0.3-debug-apk`, unzip and install `app-debug.apk`.

The APK is a debug build. The original app's signing key is not included; Android may require uninstalling an existing version before installing. **Uninstalling removes locally saved vehicle/maintenance data and settings. Back them up first.**

## AI connection
Default endpoint: `https://ladydrive-ai.onrender.com/chat`. Enter the value of Render environment variable `LADYDRIVE_ACCESS_CODE` in the AI settings. Never enter the OpenAI API key in the Android app. The access code is stored in sessionStorage, so you may need to reenter it after restarting the app.

Backend requires `OPENAI_API_KEY` and `LADYDRIVE_ACCESS_CODE` on Render. This project does not include any secret values.

## Technical changes
- WebViewAssetLoader loads assets from `https://appassets.androidplatform.net/assets/index.html`.
- POST `/chat` sends `{message,car,history}` with `x-access-code`, expects `{reply}`.
- WebView HTTPS origin avoids opaque `file://` origin. Server already sends permissive CORS headers.

Build has not been run in this environment; verify GitHub Actions output and AI POST response on device.
