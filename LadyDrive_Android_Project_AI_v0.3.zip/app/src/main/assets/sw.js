// Android WebView app: offline service worker not required.
